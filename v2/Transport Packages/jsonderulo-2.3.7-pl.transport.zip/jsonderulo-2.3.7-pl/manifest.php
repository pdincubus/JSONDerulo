<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'This work is licenced under the Creative Commons Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0)
http://creativecommons.org/licenses/by-sa/3.0/',
    'readme' => '# JSONDerulo - A JSON feed fetcher for MODX Revolution CMS

## Available snippets

### App.net

You need your user id to get this working, not your username. You can find it on your profile page. [Hat tip to "man"](https://alpha.app.net/man/post/20858).

```
<ul>
    [[!JSONDerulo?
        &feed=`appnet`
        &tpl=`jd.appNet`
        &limit=`LIMIT`
        &cacheTime=`CACHE_TIME_IN_SECONDS`
        &cacheName=`UNIQUE_NAME_FOR_CACHE_FILE`
        &userId=`USERID`
    ]]
</ul>
```

### Delicious

```
<ul>
    [[!JSONDerulo?
        &feed=`delicious`
        &tpl=`jd.delicious`
        &limit=`LIMIT`
        &cacheTime=`CACHE_TIME_IN_SECONDS`
        &cacheName=`UNIQUE_NAME_FOR_CACHE_FILE`
        &users=`USERNAME`
    ]]
</ul>
```

### Eventbrite

Requires Single user oAuth token - see \'Personal Tokens\' on the [Authentication page](http://developer.eventbrite.com/docs/auth/)
status options are: all, draft, live, cancelled, started and ended.
orderBy options are: start_asc, start_desc, created_asc and created_desc.


```
<ul>
    [[!JSONDerulo?
        &feed=`eventbrite`
        &tpl=`jd.eventbrite`
        &limit=`LIMIT`
        &status=`STATUS`
        &orderBy=`ORDER`
        &token=`YOUR_EVENTBRITE_OAUTH_TOKEN`
        &cacheTime=`CACHE_TIME_IN_SECONDS`
        &cacheName=`UNIQUE_NAME_FOR_CACHE_FILE`
    ]]
</ul>
```


### Flickr

Requires API key, get one here: [Flickr API Key](http://www.flickr.com/services/apps/create/apply)

```
<ul>
    [[!JSONDerulo?
        &feed=`flickr`
        &tpl=`jd.flickr`
        &limit=`LIMIT`
        &cacheTime=`CACHE_TIME_IN_SECONDS`
        &cacheName=`UNIQUE_NAME_FOR_CACHE_FILE`
        &users=`FLICKR USER ID`
        &apiKey=`API_KEY`
        &userName=`USERNAME`
    ]]
</ul>
```

### Google+

Requires API key, get one here: [Google API key](https://code.google.com/apis/console/)

```
<ul>
    [[!JSONDerulo?
        &feed=`googleplus`
        &tpl=`jd.googlePlus`
        &limit=`LIMIT`
        &cacheName=`UNIQUE_NAME_FOR_CACHE_FILE`
        &cacheTime=`CACHE_TIME_IN_SECONDS`
        &userId=`USER_ID`
        &apiKey=`API_KEY`
    ]]
</ul>
```

### Google calendar

You\'ll need to find the calendar\'s public feed URL. Don\'t panic, [read the instructions further down the page](#google-calendar-and-public-feed-urls)...

```
<ul>
    [[!JSONDerulo?
        &feed=`googlecalendar`
        &tpl=`jd.googleCalendar`
        &limit=`LIMIT`
        &cacheTime=`CACHE_TIME_IN_SECONDS`
        &cacheName=`UNIQUE_NAME_FOR_CACHE_FILE`
        &feedLocation=`FEED LOCATION`
    ]]
</ul>
```

### LastFM

Requires api key, get one here: [LastFM API Key](http://www.last.fm/api/account)

```
<ul>
    [[!JSONDerulo?
        &feed=`lastfm`
        &tpl=`jd.lastFm`
        &limit=`LIMIT`
        &cacheTime=`CACHE_TIME_IN_SECONDS`
        &cacheName=`UNIQUE_NAME_FOR_CACHE_FILE`
        &users=`USERNAME`
        &apiKey=`API KEY`
    ]]
</ul>
```

```
<ul>
    [[!JSONDerulo?
        &feed=`lastfmlistens`
        &tpl=`jd.lastFm`
        &limit=`LIMIT`
        &cacheTime=`CACHE_TIME_IN_SECONDS`
        &cacheName=`UNIQUE_NAME_FOR_CACHE_FILE`
        &users=`USERNAME`
        &apiKey=`API KEY`
    ]]
</ul>
```

### Tumblr

The &postType option is optional (if not set, feed will return all post types), but can be set to ```audio```, ```video```, ```photo```, ```link```, ```text```

You can only set ONE postType.

```
<ul>
    [[!JSONDerulo?
        &feed=`tumblr`
        &tpl=`jd.tumblr`
        &limit=`LIMIT`
        &cacheTime=`CACHE_TIME_IN_SECONDS`
        &cacheName=`UNIQUE_NAME_FOR_CACHE_FILE`
        &tag=`TAG TO FILTER BY`
        &postType=`POST TYPE TO FETCH`
        &notesInfo=`TRUE or FALSE`
        &blogUrl=`YOUR TUMBLR URL`
        &apiKey=`API KEY`
    ]]
</ul>
```

### Twitter

You need to set up a Twitter "App" to make this work - [from here](https://dev.twitter.com/apps). From March 2013, this is the ONLY way.

The cacheName option is for users who may want to use the snippet more than once on a site for different users\' tweets. Setting this appends the text to the cache filename so multiple feeds can be cached. I\'ve added a string replacement to swap spaces for hyphens in there too.

The screenName option is *optional*. It will allow you to fetch another user\'s timeline. If this is not provided, it will default to the user whose consumer key, etc, that you are using.

UPDATE: You can fetch and combine more than one screenName if you comma separate them. Not massively likely to be useful if you fetch more than a couple of feeds and only want a limit of 2 or 3, as you may never seen anything from some accounts if they do not tweet as regularly as any of the others you\'re pulling in.

```
<ul>
    [[!JSONDerulo?
        &feed=`twitter`
        &tpl=`jd.twitter`
        &limit=`LIMIT`
        &cacheTime=`CACHE_TIME_IN_SECONDS`
        &cacheName=`UNIQUE_NAME_TO_APPEND_TO_CACHE_FILE`
        &screenName=`USER_SCREEN_NAME_TO_FETCH_TIMELINE_FOR`
        &includeRTs=`1 or 0`
        &consumerKey=`YOUR_CONSUMER_KEY`
        &consumerSecret=`YOUR_CONSUMER_SECRET`
        &accessToken=`YOUR_ACCESS_TOKEN`
        &accessTokenSecret=`YOUR_ACCESS_TOKEN_SECRET`
        &sortDir=`ASC_OR_DESC`
    ]]
</ul>
```

### Twitter Favourites

The screenName option is *optional*. It will allow you to fetch another user\'s favourites (if public). If this is not provided, it will default to the user whose consumer key, etc, that you are using.

```
<ul>
    [[!JSONDerulo?
        &feed=`twitterFaves`
        &tpl=`jd.twitter`
        &limit=`LIMIT`
        &cacheTime=`CACHE_TIME_IN_SECONDS`
        &cacheName=`UNIQUE_NAME_TO_APPEND_TO_CACHE_FILE`
        &screenName=`USER_SCREEN_NAME_TO_FETCH_TIMELINE_FOR`
        &consumerKey=`YOUR_CONSUMER_KEY`
        &consumerSecret=`YOUR_CONSUMER_SECRET`
        &accessToken=`YOUR_ACCESS_TOKEN`
        &accessTokenSecret=`YOUR_ACCESS_TOKEN_SECRET`
    ]]
</ul>
```

### Vimeo

```
<ul>
    [[!JSONDerulo?
        &feed=`vimeo`
        &tpl=`jd.vimeo`
        &limit=`LIMIT`
        &cacheTime=`CACHE_TIME_IN_SECONDS`
        &cacheName=`UNIQUE_NAME_FOR_CACHE_FILE`
        &users=`USERNAME`
    ]]
</ul>
```

### YouTube

```
<ul>
    [[!JSONDerulo?
        &feed=`youtubev2`
        &tpl=`jd.youTube`
        &limit=`LIMIT`
        &cacheTime=`CACHE_TIME_IN_SECONDS`
        &cacheName=`UNIQUE_NAME_FOR_CACHE_FILE`
        &users=`USERNAME`
    ]]
</ul>
```

```
<ul>
    [[!JSONDerulo?
        &feed=`youtubev2uploads`
        &tpl=`jd.youTube`
        &limit=`LIMIT`
        &users=`USERNAME`
        &cacheTime=`CACHE_TIME_IN_SECONDS`
        &cacheName=`UNIQUE_NAME_FOR_CACHE_FILE`
    ]]
</ul>
```

```
<ul>
    [[!JSONDerulo?
        &feed=`youtubev3playlist`
        &tpl=`jd.youTube`
        &limit=`LIMIT`
        &cacheTime=`CACHE_TIME_IN_SECONDS`
        &cacheName=`UNIQUE_NAME_FOR_CACHE_FILE`
        &apiKey=`YOUR_V3_API_KEY`
        &playlistId=`YOUR_PLAYLIST_ID`
    ]]
</ul>
```

Grab an API key for v3 from [Google API Console](https://code.google.com/apis/console/). Ensure you switch API v3 access on!

',
    'changelog' => 'Oooo whatcha say?

For all info: https://github.com/pdincubus/JSONDerulo/

Most recent additions
---------------------
2.3.7:
    * Add sortDir option to Twitter feed. (Hat tip to creatabledesign on GitHub)
    * Added unix timestamp for tweet created on so that sorting actually sorts properly!

2.3.6:
    * FFS.

2.3.5:
    * Fix missing chunks
    * Remove ZooTool feed
    * Remove Picasa web album feed

2.3.4:
    * Move sksort function into Twitter feed part to avoid errors

2.3.3:
    * Added eventId placeholder for Eventbrite

2.3.2:
    * Lots of updates to the Eventbrite feed fetcher

2.3.1:
    * Fix wrong named chunk.

2.3.0:
    * NEW Eventbrite user events feed. More info in README and README-v2

2.2.0:
    * Added ability to fetch more than one feed and combine automatically on Twitter feed fetcher, just comma separate the screenName option, ie - &screenName=`pdincubus,modx`

2.1.0:
    * Added Twitter user favourites feed option.
    * fixed limit/count on Twitter feed

2.0.2:
    * Fix twitter feed "search" links and $user/$screenName thing.

2.0.1:
    * Tweak to ensure &feed is pulled into snippet correctly.

2.0:
    * Combined all snippets into one for ease of maintenance
    * Fixed a couple of minor stupid things
    * Chunks renamed in the transport package to be prepended with package name

1.7.4:
    * Added YouTube v.3 API public playlist fetcher.
    * twitteroauth should now avoid throwing an error about class OAuthException.

1.7.3:
    * Switch the Twitter new API to ACTUALLY use 1.1. WTF. I mean really.

1.7.2:
    * Includes merged changes from "silentworks" to allow offset and videoParams on YouTube feeds.
    * Includes cacheName option on most snippets to allow multiple snippet calls on same page to same user account

1.7.1:
    * REMOVED old style Twitter feed as API 1.0 is now officially retired.
    * Fix to make sure twitter doesn\'t caused annoying crash problem if they decide to just randomly blackout API access.
    * New Twitter chunk with ID check switch to allow for the graceful fallback for no JSON.
    * Updated MODX extra repo package link to new one.

1.7.0:
    * NEW Google calendar public events feed

1.6.0:
    * NEW Tumblr post feed

1.5.0:
    * NEW Google+ public posts feed
    * NEW TwitterFeedNewMultipleFeeds lets you choose what time of timeline to return

1.4.0:
    * New Twitter multiple timeline combining feed fetcher. See the documentation for more info.

1.3.4:
    * By request: Added configurable cacheTime option on ALL feed fetchers.

1.3.3:
    * option to view a different user\'s tweets using &screenName in the Twitter feed fetcher

1.3.2:
    * auto linking of [[+message]] in the Twitter feed for @, # and URLs
    * updated Twitter chunk to reflect this change

1.3.1:
    * minor tweaks to new Twitter feed

1.3:
    * NEW App.net feed

1.2:
    * New Twitter feed for use with updated API 1.1

1.1:
    * YouTube user upload snippet added

1.0:
    * Twitter changes for retweets.

0.9.1:
    * Slight fix for Twitter feed.

0.8:
    * Usually helps when you make sure that ALL the snippets and chunks have actually been packaged!

0.7:
    * Added Picasa album feed fetching snippet
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '399834ba1f88acd8edc80c8724eca2f5',
      'native_key' => 'jsonderulo',
      'filename' => 'modNamespace/9f8aa924a1c82308aa53145f68efcb8f.vehicle',
      'namespace' => 'jsonderulo',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'b97eafc5ceb75ca8c393e3dcfaa5749f',
      'native_key' => 1,
      'filename' => 'modCategory/52319896d53779fb992bb5c808773849.vehicle',
      'namespace' => 'jsonderulo',
    ),
  ),
);