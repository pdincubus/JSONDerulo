<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '6649fd7922a65fa7ef7d947982dbe5d1',
      'native_key' => 'jsonderulo',
      'filename' => 'modNamespace/00bec93b444b3beebf24b8dab4fa6040.vehicle',
      'namespace' => 'jsonderulo',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '55f3fbf1b2a37d48af4a87539fadbc07',
      'native_key' => 1,
      'filename' => 'modCategory/e06204d8ebcd637d350344bb150fb100.vehicle',
      'namespace' => 'jsonderulo',
    ),
  ),
);